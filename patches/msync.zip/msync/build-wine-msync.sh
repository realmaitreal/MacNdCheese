#!/usr/bin/env bash
# build-wine-msync.sh — Download Wine Staging 11.9 source, apply the msync
# patch, build, and package as a portable .app bundle for MacNCheese.
#
# Prerequisites (install via Homebrew):
#   brew install git autoconf automake libtool pkg-config mingw-w64 \
#                freetype gettext gnutls jpeg libpng bison flex molten-vk
#
# Usage:
#   bash build-wine-msync.sh [--skip-download] [--skip-patch]
#
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILD_ROOT="${HOME}/wine-msync-build"
WINE_SRC="${BUILD_ROOT}/wine-staging-src"
WINE_INSTALL="${BUILD_ROOT}/wine-msync-install"
BUNDLE_NAME="Wine Staging.app"
BUNDLE_DST="${HOME}/Library/Application Support/MacNCheese/deps/${BUNDLE_NAME}"

SKIP_DOWNLOAD=0
SKIP_PATCH=0
for arg in "$@"; do
    case "$arg" in
        --skip-download) SKIP_DOWNLOAD=1 ;;
        --skip-patch)    SKIP_PATCH=1 ;;
    esac
done

NCPU=$(sysctl -n hw.ncpu)
BREW_PREFIX=$(brew --prefix 2>/dev/null || echo "/opt/homebrew")

echo "=== MacNCheese msync Wine build ==="
echo "Build root : ${BUILD_ROOT}"
echo "Install to : ${BUNDLE_DST}"
echo ""

mkdir -p "${BUILD_ROOT}"

# ── 1. Get Wine Staging 11.9 source ────────────────────────────────────────
if [[ $SKIP_DOWNLOAD -eq 0 ]]; then
    echo "→ Fetching Wine Staging 11.9 source..."
    cd "${BUILD_ROOT}"

    # Try downloading the release tarball from Gcenx's wine-staging fork or
    # official wine-staging mirror.
    STAGING_URL=""
    for url in \
        "https://github.com/wine-staging/wine-staging/archive/refs/tags/v11.9.tar.gz" \
        "https://github.com/Gcenx/wine-crossover/archive/refs/tags/11.9.tar.gz"; do
        if curl --output /dev/null --silent --head --fail "$url"; then
            STAGING_URL="$url"
            break
        fi
    done

    if [[ -z "$STAGING_URL" ]]; then
        echo "ERROR: Could not find a wine-staging 11.9 tarball."
        echo "Please download Wine Staging 11.9 source manually and extract to:"
        echo "  ${WINE_SRC}"
        echo "Then re-run with --skip-download."
        exit 1
    fi

    echo "Downloading ${STAGING_URL}..."
    curl -L "$STAGING_URL" -o wine-staging-src.tar.gz
    rm -rf "${WINE_SRC}"
    mkdir -p "${WINE_SRC}"
    tar -xf wine-staging-src.tar.gz -C "${WINE_SRC}" --strip-components=1
    rm wine-staging-src.tar.gz
    echo "Extracted to ${WINE_SRC}"
else
    echo "→ Skipping download (using existing ${WINE_SRC})"
    if [[ ! -d "${WINE_SRC}" ]]; then
        echo "ERROR: ${WINE_SRC} does not exist. Run without --skip-download first."
        exit 1
    fi
fi

# ── 2. Apply msync patch ────────────────────────────────────────────────────
if [[ $SKIP_PATCH -eq 0 ]]; then
    echo ""
    echo "→ Applying msync patch..."
    cd "${WINE_SRC}"
    python3 "${PATCH_DIR}/apply.py"
else
    echo "→ Skipping patch."
fi

# ── 3. Configure ───────────────────────────────────────────────────────────
echo ""
echo "→ Running autoreconf and configure..."
cd "${WINE_SRC}"

if [[ ! -f configure ]]; then
    autoreconf -fi
fi

# Build only 64-bit (ARM64 native) — no 32-bit Wine on Apple Silicon
HOMEBREW_LIBS="${BREW_PREFIX}/lib"
HOMEBREW_INCS="${BREW_PREFIX}/include"

./configure \
    --prefix="${WINE_INSTALL}" \
    --enable-archs=x86_64 \
    --without-x \
    --without-opengl \
    --without-vulkan \
    --with-freetype \
    --with-gnutls \
    --with-gettext \
    CFLAGS="-O2 -I${HOMEBREW_INCS}" \
    LDFLAGS="-L${HOMEBREW_LIBS}" \
    PKG_CONFIG_PATH="${HOMEBREW_LIBS}/pkgconfig" \
    2>&1 | tail -20

# ── 4. Build ───────────────────────────────────────────────────────────────
echo ""
echo "→ Building Wine with ${NCPU} parallel jobs (this takes 20-40 min)..."
make -j"${NCPU}" 2>&1 | grep -E "^(make|error:|warning: unused|msync)" || true
make -j"${NCPU}"

# ── 5. Install ─────────────────────────────────────────────────────────────
echo ""
echo "→ Installing to ${WINE_INSTALL}..."
make install

# ── 6. Package as .app bundle ──────────────────────────────────────────────
echo ""
echo "→ Packaging as ${BUNDLE_NAME}..."

BUNDLE="${BUNDLE_DST}"
WINE_RES="${BUNDLE}/Contents/Resources/wine"

mkdir -p "${BUNDLE}/Contents/MacOS" "${WINE_RES}"

# Create the Contents/Info.plist
cat > "${BUNDLE}/Contents/Info.plist" << 'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleIdentifier</key>
    <string>org.winehq.wine-staging-msync</string>
    <key>CFBundleName</key>
    <string>Wine Staging (msync)</string>
    <key>CFBundleVersion</key>
    <string>11.9-msync</string>
</dict>
</plist>
PLIST

# Launcher stub
cat > "${BUNDLE}/Contents/MacOS/wine" << 'LAUNCHER'
#!/bin/bash
DIR="$(cd "$(dirname "$0")/../../Resources/wine/bin" && pwd)"
exec "$DIR/wine64" "$@"
LAUNCHER
chmod +x "${BUNDLE}/Contents/MacOS/wine"

# Copy installed wine into bundle
rsync -a --delete "${WINE_INSTALL}/" "${WINE_RES}/"

echo ""
echo "=== Done! ==="
echo ""
echo "Wine Staging 11.9 + msync installed to:"
echo "  ${BUNDLE_DST}"
echo ""
echo "MacNCheese will pick it up automatically as 'Wine Staging'."
echo "Enable msync per-game in the launch sheet (or set WINEMSYNC=1)."
